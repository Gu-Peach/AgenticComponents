"""Method-one process verifier. No PLC generation or dispatch optimization."""
__version__ = "0.1.0"
